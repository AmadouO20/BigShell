#pragma once

/** exits bigshell (cleanly) */
extern void bigshell_exit(void);
